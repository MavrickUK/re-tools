# Board4All Utils CLI v0.2.19 - 11 Oct 2024 - Windows 64
Utils CLI v0.2.19 - 11 Oct 2024 - Windows 64

## SHA256
3469601FD6BEEF0C6255D7D4D9A6133ABD31B175E367F963AA49918E144942AF *b4a.exe

## Info
Made, by me, as a fun tool while learning Golang.
This console command application has a few network related tools that I found handy to have in one place.

### UPX Packed
You can unpack the exe if you wish, I know some AV's have issue with the latest UPX version.

### Installation
None required! Just run from the terminal. Make sure the **.b4a.yaml** file is in the same directory.

### Usage
b4a.exe -h
Just run `b4a.exe`. Use `b4a.exe --help` to view all options.

### Note
To be able to use the `ipgeo` command you need to register with `ipstack.com` and get a *FREE* API ACCESS KEY.

Paste the `api key` in the placeholder in the `.b4a.yaml` file.
Pick the free package which allows for 100 requests per month.

### License:
This project is licenced under a Simplified BSD license. Please read the [LICENSE](LICENSE) file.

Regards Mavrick

See you on the board ;)