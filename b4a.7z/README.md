# Board4All Utils CLI v0.1.18 - 1 Oct 2024 - Windows 64

## SHA256
013F457A1C55D96B6A69135D0E7AC3A0AAD83E9D8DF4579BD55B26D27D970BC7 *b4a.exe

## Info
Made, by me, as a fun tool while learning Golang.
This console command application has a few network related tools that I found handy to have in one place.

### UPX Packed
You can unpack the exe if you wish, I know some AV's have issue with the latest UPX version.

### Installation
None required! Just run from the terminal. Make sure the **.b4a.yaml** file is in the same directory.

### Usage
b4a.exe -h
Just run `b4a.exe`. Use `b4a.exe --help` to view all options.

### Note
To be able to use the `ipgeo` command you need to register with `ipstack.com` and get a *FREE* API ACCESS KEY.

Paste the `api key` in the placeholder in the `.b4a.yaml` file.
Pick the free package which allows for 100 requests per month.

### License:
This project is licenced under a Simplified BSD license. Please read the [LICENSE](LICENSE) file.

Regards Mavrick

See you on the board ;)